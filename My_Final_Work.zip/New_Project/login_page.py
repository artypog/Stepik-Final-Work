from base_page import BasePage
import locators
from locators import BasePageLocators


class LoginPage(BasePage):
    def should_be_login_page(self):
        self.should_be_login_url()
        self.should_be_login_form()
        self.should_be_register_form()
        self.register_new_user()

    def should_be_login_url(self):
        # реализуйте проверку на корректный url адрес
        assert 'login' in self.browser.current_url, "Окно регистрации/авторизации не открыто"


    def should_be_login_form(self):
        # реализуйте проверку, что есть форма логина
        assert locators.LoginPageLocators.LOGIN_LINK, "не найдено поле для ввода логина"

    def should_be_register_form(self):
        # реализуйте проверку, что есть форма регистрации на странице
        assert locators.LoginPageLocators.REGISTRATION_LINK, "не найдено поле для ввода регистрационного имени"

    def register_new_user(email, password):
        link = BasePageLocators.LOGIN_LINK
        link.click()
        link = BasePageLocators.REGISTRATION_LINK
        link.send_keys(email)
        link = BasePageLocators.PASSWORD1_LINK
        link.send_keys(password)
        link = BasePageLocators.PASSWORD2_LINK
        link.send_keys(password)
        link = BasePageLocators.REGISTRATION_BUTTON_LINK
        link.click()




class OpenPage(BasePage):
    def should_be_add_to_basket_button(self):
        # Должна присутствовать кнопка добавления в корзину
        assert locators.AddToBasket.BASKET_BUTTON_LINK, "не найдена кнопка добавления в корзину"
