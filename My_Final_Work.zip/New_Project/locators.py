from selenium.webdriver.common.by import By


# class MainPageLocators():
#     LOGIN_LINK = (By.CSS_SELECTOR, "#login_link")
#
#
class LoginPageLocators():
    LOGIN_LINK = (By.CSS_SELECTOR, "#id_login-username")
    REGISTRATION_LINK = (By.CSS_SELECTOR, "#id_registration-email")

class AddToBasket():
    BASKET_BUTTON_LINK = (By.CLASS_NAME, "btn.btn-lg.btn-primary.btn-add-to-basket")

class BasePageLocators():
    LOGIN_LINK = (By.CSS_SELECTOR, "#login_link")
    LOGIN_LINK_INVALID = (By.CSS_SELECTOR, "#login_link_inc")
    REGISTRATION_LINK = (By.ID, "id_registration-email")
    PASSWORD1_LINK = (By.ID, "id_registration-password1")
    PASSWORD2_LINK = (By.ID, "id_registration-password2")
    BASKET_LINK = (By.CSS_SELECTOR, ".btn-group a")
    NO_GODS_LINK = (By.CLASS_NAME, "col-sm-6.h3")
    REGISTRATION_BUTTON_LINK = (By.CLASS_NAME, ".btn.btn-lg.btn-primary")
