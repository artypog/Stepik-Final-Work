import time

from selenium.webdriver.common.alert import Alert

from base_page import BasePage
from selenium.webdriver.common.by import By
from locators import AddToBasket

from login_page import OpenPage
from selenium.common.exceptions import NoAlertPresentException # в начале файла
import math

# class MainPage(BasePage):
#     def go_to_login_page(self):
#         # login_link = self.browser.find_element(By.CSS_SELECTOR, "#login_link")
#         # login_link.click()
#         link = self.browser.find_element(By.CLASS_NAME, "btn.btn-lg.btn-primary.btn-add-to-basket")
#         link.click()
#         time.sleep(1)
#         solve_quiz_and_get_code(self)
#         # return LoginPage(browser=self.browser, url=self.browser.current_url)
#
# # def should_be_login_link(self):
# #         self.browser.find_element(By.CSS_SELECTOR, "#login_link_invalid")


class MainPage(BasePage):
    def __init__(self, *args, **kwargs):
        super(MainPage, self).__init__(*args, **kwargs)



def solve_quiz_and_get_code(self):
    alert = self.browser.switch_to.alert

    x = alert.text.split(" ")[2]
    answer = str(math.log(abs((12 * math.sin(float(x))))))
    alert.send_keys(answer)
    alert.accept()
    try:
        alert = self.browser.switch_to.alert
        alert_text = alert.text
        print(f"Your code: {alert_text}")
        alert.accept()
    except NoAlertPresentException:
        print("No second alert presented")