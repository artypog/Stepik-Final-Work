import math
def calc(x):
    print ({math.log(abs((12 * math.sin(float(x)))))})

print(calc(771))